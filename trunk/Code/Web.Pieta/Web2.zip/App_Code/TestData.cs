﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for TestData
/// </summary>
public class TestData
{
    public string Title { get; set; }
    public float Price { get; set; }
    public string Description { get; set; }

    public TestData()
    { }

    //
    // TODO: Add constructor logic here
    //

}