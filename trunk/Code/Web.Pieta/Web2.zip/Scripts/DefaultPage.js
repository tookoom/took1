﻿$(document).ready(function () {
    //alert('teste');
    //$('#date').datepicker();
    });